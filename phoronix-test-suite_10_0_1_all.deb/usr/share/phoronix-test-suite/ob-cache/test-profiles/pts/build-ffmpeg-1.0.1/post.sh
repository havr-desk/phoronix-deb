#!/bin/sh

rm -rf ffmpeg-4.2.2
