#!/bin/sh

rm -rf ImageMagick-6.9.0-0/

