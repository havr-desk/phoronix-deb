#!/bin/sh

cd linux-3.18-rc6/
make clean
