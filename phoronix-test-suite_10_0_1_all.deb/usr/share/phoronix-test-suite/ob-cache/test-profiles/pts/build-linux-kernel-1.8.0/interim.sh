#!/bin/sh

cd linux-4.13/
make clean
