#!/bin/sh
rm -rf linux-4.18/
