#!/bin/sh

rm -rf gdb-9.1/build
