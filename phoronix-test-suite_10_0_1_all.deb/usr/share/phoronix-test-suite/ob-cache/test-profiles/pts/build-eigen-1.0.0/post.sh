#!/bin/sh

rm -rf eigen-eigen-bdd17ee3b1b3
