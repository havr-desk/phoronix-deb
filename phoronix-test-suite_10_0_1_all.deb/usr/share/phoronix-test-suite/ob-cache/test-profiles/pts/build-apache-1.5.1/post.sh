#!/bin/sh

rm -rf httpd/
